from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, abort, make_response
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime, timedelta
import os
import secrets
import re
import hashlib
import time
from functools import wraps
from collections import defaultdict

app = Flask(__name__)
# Strong secret key
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)

# Session security
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=False,  # True in production with HTTPS
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,  # 1 MB max upload
)

# Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Пожалуйста, войдите для доступа к этой странице.'
login_manager.login_message_category = 'warning'
login_manager.session_protection = 'strong'

DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shop.db')

# In-memory rate limiting (IP -> list of timestamps)
_login_attempts = defaultdict(list)
_register_attempts = defaultdict(list)
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_MINUTES = 15
MAX_REGISTER_ATTEMPTS = 3

# ==================== HELPERS ====================

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn

def get_client_ip():
    return request.headers.get('X-Forwarded-For', request.remote_addr) or '0.0.0.0'

def sanitize(text, max_len=500):
    """Basic sanitization: strip, limit length, remove control chars."""
    if not text:
        return ''
    text = str(text).strip()
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
    return text[:max_len]

def is_valid_email(email):
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))

def is_strong_password(password):
    if len(password) < 6:
        return False, 'Пароль должен быть не менее 6 символов'
    return True, ''

def check_rate_limit(store, ip, max_attempts, window_minutes):
    now = time.time()
    window = window_minutes * 60
    store[ip] = [t for t in store[ip] if now - t < window]
    if len(store[ip]) >= max_attempts:
        return False
    return True

def record_attempt(store, ip):
    store[ip].append(time.time())

def log_audit(action, details='', user_id=None, severity='info'):
    """Write an entry to the audit log."""
    try:
        conn = get_db()
        uid = user_id
        if uid is None and hasattr(current_user, 'is_authenticated') and current_user.is_authenticated:
            uid = current_user.id
        conn.execute(
            '''INSERT INTO audit_log (user_id, action, details, ip_address, user_agent, severity)
               VALUES (?, ?, ?, ?, ?, ?)''',
            (uid, action, sanitize(details, 1000), get_client_ip(),
             sanitize(request.headers.get('User-Agent', ''), 300), severity)
        )
        conn.commit()
        conn.close()
    except Exception:
        pass  # never break the app because of audit

def generate_csrf_token():
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']

def validate_csrf():
    token = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
    if not token or token != session.get('_csrf_token'):
        log_audit('csrf_fail', f'Path: {request.path}', severity='warning')
        abort(403)

# ==================== DB INIT ====================

def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        failed_logins INTEGER DEFAULT 0,
        locked_until TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        icon TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        old_price REAL,
        category_id INTEGER,
        image_url TEXT,
        stock INTEGER DEFAULT 50,
        brand TEXT,
        rating REAL DEFAULT 4.5,
        features TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS cart (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 1,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (product_id) REFERENCES products(id),
        UNIQUE(user_id, product_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        total REAL NOT NULL,
        status TEXT DEFAULT 'pending',
        address TEXT,
        phone TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    # Audit log
    c.execute('''CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        details TEXT,
        ip_address TEXT,
        user_agent TEXT,
        severity TEXT DEFAULT 'info',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    # Migrate: add columns if missing (for existing DBs)
    for col, typedef in [
        ('is_active', 'INTEGER DEFAULT 1'),
        ('failed_logins', 'INTEGER DEFAULT 0'),
        ('locked_until', 'TIMESTAMP'),
    ]:
        try:
            c.execute(f'ALTER TABLE users ADD COLUMN {col} {typedef}')
        except sqlite3.OperationalError:
            pass

    conn.commit()

    # Seed
    c.execute('SELECT COUNT(*) FROM categories')
    if c.fetchone()[0] == 0:
        categories = [
            ('Мыши', 'mice', '🖱️'),
            ('Клавиатуры', 'keyboards', '⌨️'),
            ('Наушники', 'headsets', '🎧'),
            ('Коврики', 'mousepads', '🖼️'),
            ('Геймпады', 'controllers', '🎮'),
            ('Мониторы', 'monitors', '🖥️'),
        ]
        c.executemany('INSERT INTO categories (name, slug, icon) VALUES (?, ?, ?)', categories)

        products = [
            ('Logitech G Pro X Superlight 2', 'Легчайшая беспроводная игровая мышь весом всего 60г. Сенсор HERO 2, 32K DPI, оптические переключатели.', 14990, 17990, 1, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400', 25, 'Logitech', 4.9, '60г, 32K DPI, 95 часов батареи, Lightspeed'),
            ('Razer Viper V3 Pro', 'Профессиональная киберспортивная мышь. Focus Pro 30K сенсор, 54г.', 13990, None, 1, 'https://images.unsplash.com/photo-1615662977969-6c2d7c0e2e5c?w=400', 30, 'Razer', 4.8, '54г, 30K DPI, 90 часов, HyperSpeed'),
            ('SteelSeries Aerox 5 Wireless', 'Ультралёгкая мышь с RGB и боковыми кнопками. 74г.', 9990, 12990, 1, 'https://images.unsplash.com/photo-1563297007-0686b7003af7?w=400', 40, 'SteelSeries', 4.6, '74г, 18K DPI, AquaGuard, RGB'),
            ('Zowie EC2-CW', 'Беспроводная версия легендарной EC2. Эргономичная форма.', 11990, None, 1, 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=400', 15, 'Zowie', 4.7, 'Эргономика, 3200 DPI, беспроводная'),
            ('Razer BlackWidow V4 Pro', 'Механическая клавиатура с OLED дисплеем и Command Dial.', 24990, 29990, 2, 'https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=400', 20, 'Razer', 4.8, 'Razer Green, OLED, Command Dial, RGB'),
            ('Keychron Q1 Pro', 'Кастомная механическая клавиатура 75%. Беспроводная, Gasket Mount.', 18990, None, 2, 'https://images.unsplash.com/photo-1587829741301-dc430b73f898?w=400', 35, 'Keychron', 4.9, 'Gasket Mount, Hot-swap, Bluetooth/2.4G'),
            ('Corsair K70 RGB Pro', 'Алюминиевая рамка, переключатели Cherry MX, медиа-колёсико.', 16990, 19990, 2, 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=400', 28, 'Corsair', 4.7, 'Cherry MX Red, RGB, Aluminum'),
            ('Logitech G915 TKL', 'Низкопрофильная беспроводная механика. Lightspeed + Bluetooth.', 21990, None, 2, 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=400', 18, 'Logitech', 4.6, 'GL Tactile, TKL, 40 часов'),
            ('HyperX Cloud III', 'Легендарный комфорт. 53мм драйверы, съёмный микрофон.', 8990, 10990, 3, 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400', 50, 'HyperX', 4.8, '53мм, DTS, Memory foam, USB/3.5mm'),
            ('SteelSeries Arctis Nova Pro Wireless', 'Премиум беспроводная гарнитура с активным шумоподавлением.', 34990, None, 3, 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400', 12, 'SteelSeries', 4.9, 'ANC, Dual battery, 360° Spatial'),
            ('Razer BlackShark V2 Pro', 'Киберспортивная гарнитура с THX Spatial Audio.', 15990, 18990, 3, 'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=400', 22, 'Razer', 4.7, 'THX, 50мм, HyperClear mic'),
            ('Sony INZONE H9', 'Беспроводные с ANC и 360 Spatial Sound от Sony.', 27990, None, 3, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400', 15, 'Sony', 4.5, 'ANC, 360 Spatial, 32 часа'),
            ('SteelSeries QcK Heavy XXL', 'Толстый тканевый коврик 900x400x4мм.', 2990, 3490, 4, 'https://images.unsplash.com/photo-1616587894289-86480e533129?w=400', 100, 'SteelSeries', 4.8, '900x400, 4мм, ткань'),
            ('Artisan Zero Soft XL', 'Премиум японский коврик. Контроль и скорость.', 5990, None, 4, 'https://images.unsplash.com/photo-1625948515291-69613efd103f?w=400', 40, 'Artisan', 4.9, 'Soft, XL, Япония'),
            ('Razer Firefly V2', 'RGB коврик с микротекстурированной поверхностью.', 4990, 5990, 4, 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=400', 60, 'Razer', 4.5, 'RGB, Hard, Chroma'),
            ('Sony DualSense Edge', 'Профессиональный геймпад с сменными стиками и кнопками.', 19990, None, 5, 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400', 25, 'Sony', 4.8, 'Сменные модули, Trigger stops, PC/PS5'),
            ('Xbox Elite Series 2', 'Премиум геймпад с настраиваемыми стиками и кнопками.', 17990, 19990, 5, 'https://images.unsplash.com/photo-1621259182978-fbf93132d53d?w=400', 30, 'Microsoft', 4.7, 'Сменные стики, Hair Triggers, 40 часов'),
            ('Razer Wolverine V2 Chroma', 'Проводной геймпад с RGB и дополнительными кнопками.', 9990, None, 5, 'https://images.unsplash.com/photo-1592840496694-26d035b52b48?w=400', 35, 'Razer', 4.6, 'RGB, Mecha-Tactile, PC/Xbox'),
            ('ASUS ROG Swift PG27AQDM', '27" OLED 240Hz, 0.03ms, HDR10.', 89990, 99990, 6, 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400', 8, 'ASUS', 4.9, 'OLED, 240Hz, 0.03ms, G-Sync'),
            ('LG UltraGear 27GP950', '27" 4K 144Hz Nano IPS, HDMI 2.1.', 54990, 64990, 6, 'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=400', 12, 'LG', 4.7, '4K, 144Hz, HDMI 2.1, HDR600'),
            ('Samsung Odyssey G7 32"', '32" QHD 240Hz, 1000R, VA.', 39990, 44990, 6, 'https://images.unsplash.com/photo-1616763355548-1b606f371b53?w=400', 15, 'Samsung', 4.6, 'QHD, 240Hz, 1000R, HDR600'),
        ]
        c.executemany('''INSERT INTO products
            (name, description, price, old_price, category_id, image_url, stock, brand, rating, features)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', products)

        admin_hash = generate_password_hash('admin123')
        c.execute('INSERT INTO users (username, email, password_hash, is_admin) VALUES (?, ?, ?, ?)',
                  ('admin', 'admin@gamingshop.ru', admin_hash, 1))
        user_hash = generate_password_hash('demo123')
        c.execute('INSERT INTO users (username, email, password_hash, is_admin) VALUES (?, ?, ?, ?)',
                  ('demo', 'demo@mail.ru', user_hash, 0))
        conn.commit()

    conn.close()

# ==================== USER MODEL ====================

class User(UserMixin):
    def __init__(self, id, username, email, is_admin=False, is_active=True):
        self.id = id
        self.username = username
        self.email = email
        self.is_admin = is_admin
        self._is_active = is_active

    @property
    def is_active(self):
        return bool(self._is_active)

@login_manager.user_loader
def load_user(user_id):
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    if user and user['is_active']:
        return User(user['id'], user['username'], user['email'], user['is_admin'], user['is_active'])
    return None

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            log_audit('admin_access_denied', f'Path: {request.path}', severity='warning')
            flash('Доступ только для администратора', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

# ==================== SECURITY HEADERS ====================

@app.after_request
def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "img-src 'self' data: https: http:; "
        "font-src 'self' https://cdn.jsdelivr.net; "
        "frame-ancestors 'self';"
    )
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private'
    return response

@app.context_processor
def inject_globals():
    data = {'csrf_token': generate_csrf_token, 'cart_count': 0}
    if current_user.is_authenticated:
        try:
            conn = get_db()
            count = conn.execute(
                'SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE user_id = ?',
                (current_user.id,)
            ).fetchone()[0]
            conn.close()
            data['cart_count'] = count
        except Exception:
            pass
    return data

# ==================== PUBLIC ROUTES ====================

@app.route('/')
def index():
    conn = get_db()
    categories = conn.execute('SELECT * FROM categories').fetchall()
    products = conn.execute('''
        SELECT p.*, c.name as category_name, c.slug as category_slug
        FROM products p JOIN categories c ON p.category_id = c.id
        ORDER BY p.rating DESC LIMIT 8
    ''').fetchall()
    conn.close()
    return render_template('index.html', products=products, categories=categories)

@app.route('/catalog')
def catalog():
    conn = get_db()
    category_slug = sanitize(request.args.get('category', ''), 50)
    search = sanitize(request.args.get('q', ''), 100)
    sort = sanitize(request.args.get('sort', 'rating'), 20)
    brand = sanitize(request.args.get('brand', ''), 50)

    query = '''SELECT p.*, c.name as category_name, c.slug as category_slug
               FROM products p JOIN categories c ON p.category_id = c.id WHERE 1=1'''
    params = []

    if category_slug:
        query += ' AND c.slug = ?'
        params.append(category_slug)
    if search:
        query += ' AND (p.name LIKE ? OR p.description LIKE ? OR p.brand LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%', f'%{search}%'])
    if brand:
        query += ' AND p.brand = ?'
        params.append(brand)

    sort_map = {
        'price_asc': ' ORDER BY p.price ASC',
        'price_desc': ' ORDER BY p.price DESC',
        'name': ' ORDER BY p.name ASC',
    }
    query += sort_map.get(sort, ' ORDER BY p.rating DESC')

    products = conn.execute(query, params).fetchall()
    categories = conn.execute('SELECT * FROM categories').fetchall()
    brands = conn.execute('SELECT DISTINCT brand FROM products ORDER BY brand').fetchall()
    conn.close()
    return render_template('catalog.html', products=products, categories=categories,
                           brands=brands, current_category=category_slug,
                           search=search, sort=sort, current_brand=brand)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    conn = get_db()
    product = conn.execute('''
        SELECT p.*, c.name as category_name, c.slug as category_slug
        FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?
    ''', (product_id,)).fetchone()
    if not product:
        flash('Товар не найден', 'danger')
        conn.close()
        return redirect(url_for('catalog'))
    reviews = conn.execute('''
        SELECT r.*, u.username FROM reviews r JOIN users u ON r.user_id = u.id
        WHERE r.product_id = ? ORDER BY r.created_at DESC
    ''', (product_id,)).fetchall()
    related = conn.execute(
        'SELECT * FROM products WHERE category_id = ? AND id != ? LIMIT 4',
        (product['category_id'], product_id)
    ).fetchall()
    conn.close()
    return render_template('product.html', product=product, reviews=reviews, related=related)

# ==================== AUTH ====================

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        validate_csrf()
        ip = get_client_ip()
        if not check_rate_limit(_register_attempts, ip, MAX_REGISTER_ATTEMPTS, 30):
            flash('Слишком много попыток регистрации. Подождите 30 минут.', 'danger')
            log_audit('register_rate_limit', f'IP: {ip}', severity='warning')
            return render_template('register.html')

        username = sanitize(request.form.get('username', ''), 50)
        email = sanitize(request.form.get('email', ''), 120).lower()
        password = request.form.get('password', '')
        password2 = request.form.get('password2', '')

        if not username or not email or not password:
            flash('Заполните все поля', 'danger')
            return render_template('register.html')
        if not re.match(r'^[a-zA-Z0-9_]{3,30}$', username):
            flash('Имя: 3–30 символов, только латиница, цифры и _', 'danger')
            return render_template('register.html')
        if not is_valid_email(email):
            flash('Некорректный email', 'danger')
            return render_template('register.html')
        if password != password2:
            flash('Пароли не совпадают', 'danger')
            return render_template('register.html')
        ok, msg = is_strong_password(password)
        if not ok:
            flash(msg, 'danger')
            return render_template('register.html')

        record_attempt(_register_attempts, ip)
        conn = get_db()
        try:
            password_hash = generate_password_hash(password, method='scrypt')
            conn.execute(
                'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                (username, email, password_hash)
            )
            conn.commit()
            log_audit('register', f'New user: {username}', severity='info')
            flash('Регистрация успешна! Теперь войдите.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Пользователь с таким именем или email уже существует', 'danger')
            log_audit('register_duplicate', f'Attempt: {username}/{email}', severity='info')
        finally:
            conn.close()

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        validate_csrf()
        ip = get_client_ip()
        if not check_rate_limit(_login_attempts, ip, MAX_LOGIN_ATTEMPTS, LOCKOUT_MINUTES):
            flash(f'Слишком много попыток входа. Подождите {LOCKOUT_MINUTES} минут.', 'danger')
            log_audit('login_rate_limit', f'IP: {ip}', severity='warning')
            return render_template('login.html')

        username = sanitize(request.form.get('username', ''), 120)
        password = request.form.get('password', '')

        conn = get_db()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? OR email = ?', (username, username)
        ).fetchone()

        if user:
            # Check lock
            if user['locked_until']:
                try:
                    locked = datetime.fromisoformat(user['locked_until'])
                    if locked > datetime.now():
                        flash('Аккаунт временно заблокирован. Попробуйте позже.', 'danger')
                        log_audit('login_locked', f'User: {username}', user_id=user['id'], severity='warning')
                        conn.close()
                        return render_template('login.html')
                except (ValueError, TypeError):
                    pass

            if not user['is_active']:
                flash('Аккаунт деактивирован. Обратитесь к администратору.', 'danger')
                log_audit('login_inactive', f'User: {username}', user_id=user['id'], severity='warning')
                conn.close()
                return render_template('login.html')

            if check_password_hash(user['password_hash'], password):
                # Success — reset failed logins
                conn.execute(
                    'UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?',
                    (user['id'],)
                )
                conn.commit()
                user_obj = User(user['id'], user['username'], user['email'], user['is_admin'], user['is_active'])
                login_user(user_obj, remember=True)
                session.permanent = True
                log_audit('login_success', f'User: {user["username"]}', user_id=user['id'])
                flash(f'Добро пожаловать, {user["username"]}!', 'success')
                conn.close()
                next_page = request.args.get('next')
                if next_page and next_page.startswith('/'):
                    return redirect(next_page)
                return redirect(url_for('index'))
            else:
                # Failed password
                fails = (user['failed_logins'] or 0) + 1
                locked_until = None
                if fails >= MAX_LOGIN_ATTEMPTS:
                    locked_until = (datetime.now() + timedelta(minutes=LOCKOUT_MINUTES)).isoformat()
                    fails = 0
                conn.execute(
                    'UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?',
                    (fails, locked_until, user['id'])
                )
                conn.commit()
                record_attempt(_login_attempts, ip)
                log_audit('login_fail', f'User: {username}, fails={fails}', user_id=user['id'], severity='warning')
                flash('Неверное имя пользователя или пароль', 'danger')
        else:
            record_attempt(_login_attempts, ip)
            log_audit('login_fail', f'Unknown user: {username}', severity='warning')
            flash('Неверное имя пользователя или пароль', 'danger')

        conn.close()

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    log_audit('logout', f'User: {current_user.username}')
    logout_user()
    session.clear()
    flash('Вы вышли из аккаунта', 'info')
    return redirect(url_for('index'))

# ==================== CART / ORDERS ====================

@app.route('/cart')
@login_required
def cart():
    conn = get_db()
    items = conn.execute('''
        SELECT c.id as cart_id, c.quantity, p.*, (c.quantity * p.price) as subtotal
        FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?
    ''', (current_user.id,)).fetchall()
    total = sum(item['subtotal'] for item in items)
    conn.close()
    return render_template('cart.html', items=items, total=total)

@app.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    validate_csrf()
    try:
        quantity = int(request.form.get('quantity', 1))
    except (ValueError, TypeError):
        quantity = 1
    quantity = max(1, min(quantity, 99))

    conn = get_db()
    product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    if not product:
        flash('Товар не найден', 'danger')
        conn.close()
        return redirect(url_for('catalog'))
    if product['stock'] < quantity:
        flash('Недостаточно товара на складе', 'warning')
        conn.close()
        return redirect(url_for('product_detail', product_id=product_id))

    existing = conn.execute(
        'SELECT * FROM cart WHERE user_id = ? AND product_id = ?',
        (current_user.id, product_id)
    ).fetchone()
    if existing:
        new_qty = existing['quantity'] + quantity
        if new_qty > product['stock']:
            flash('Недостаточно товара на складе', 'warning')
        else:
            conn.execute('UPDATE cart SET quantity = ? WHERE id = ?', (new_qty, existing['id']))
            conn.commit()
            flash('Количество товара в корзине обновлено', 'success')
    else:
        conn.execute(
            'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)',
            (current_user.id, product_id, quantity)
        )
        conn.commit()
        flash('Товар добавлен в корзину', 'success')
    conn.close()
    return redirect(request.referrer or url_for('catalog'))

@app.route('/cart/update/<int:cart_id>', methods=['POST'])
@login_required
def update_cart(cart_id):
    validate_csrf()
    try:
        quantity = int(request.form.get('quantity', 1))
    except (ValueError, TypeError):
        quantity = 1

    conn = get_db()
    item = conn.execute(
        'SELECT c.*, p.stock FROM cart c JOIN products p ON c.product_id = p.id WHERE c.id = ? AND c.user_id = ?',
        (cart_id, current_user.id)
    ).fetchone()
    if not item:
        flash('Товар не найден в корзине', 'danger')
        conn.close()
        return redirect(url_for('cart'))
    if quantity <= 0:
        conn.execute('DELETE FROM cart WHERE id = ?', (cart_id,))
        flash('Товар удалён из корзины', 'info')
    elif quantity > item['stock']:
        flash('Недостаточно товара на складе', 'warning')
    else:
        conn.execute('UPDATE cart SET quantity = ? WHERE id = ?', (quantity, cart_id))
        flash('Корзина обновлена', 'success')
    conn.commit()
    conn.close()
    return redirect(url_for('cart'))

@app.route('/cart/remove/<int:cart_id>', methods=['POST'])
@login_required
def remove_from_cart(cart_id):
    validate_csrf()
    conn = get_db()
    conn.execute('DELETE FROM cart WHERE id = ? AND user_id = ?', (cart_id, current_user.id))
    conn.commit()
    conn.close()
    flash('Товар удалён из корзины', 'info')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    conn = get_db()
    items = conn.execute('''
        SELECT c.quantity, p.*, (c.quantity * p.price) as subtotal
        FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?
    ''', (current_user.id,)).fetchall()
    if not items:
        flash('Корзина пуста', 'warning')
        conn.close()
        return redirect(url_for('cart'))
    total = sum(item['subtotal'] for item in items)

    if request.method == 'POST':
        validate_csrf()
        address = sanitize(request.form.get('address', ''), 300)
        phone = sanitize(request.form.get('phone', ''), 30)
        if not address or not phone:
            flash('Заполните адрес и телефон', 'danger')
            conn.close()
            return render_template('checkout.html', items=items, total=total)
        if not re.match(r'^[\d\s\+\-\(\)]{7,20}$', phone):
            flash('Некорректный номер телефона', 'danger')
            conn.close()
            return render_template('checkout.html', items=items, total=total)

        for item in items:
            if item['quantity'] > item['stock']:
                flash(f'Недостаточно товара: {item["name"]}', 'danger')
                conn.close()
                return redirect(url_for('cart'))

        cursor = conn.execute(
            'INSERT INTO orders (user_id, total, address, phone, status) VALUES (?, ?, ?, ?, ?)',
            (current_user.id, total, address, phone, 'processing')
        )
        order_id = cursor.lastrowid
        for item in items:
            conn.execute(
                'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
                (order_id, item['id'], item['quantity'], item['price'])
            )
            conn.execute('UPDATE products SET stock = stock - ? WHERE id = ?',
                        (item['quantity'], item['id']))
        conn.execute('DELETE FROM cart WHERE user_id = ?', (current_user.id,))
        conn.commit()
        conn.close()
        log_audit('order_created', f'Order #{order_id}, total={total}', severity='info')
        flash(f'Заказ №{order_id} успешно оформлен! Сумма: {total:,.0f} ₽', 'success')
        return redirect(url_for('orders'))

    conn.close()
    return render_template('checkout.html', items=items, total=total)

@app.route('/orders')
@login_required
def orders():
    conn = get_db()
    user_orders = conn.execute(
        'SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC',
        (current_user.id,)
    ).fetchall()
    orders_with_items = []
    for order in user_orders:
        items = conn.execute('''
            SELECT oi.*, p.name, p.image_url FROM order_items oi
            JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?
        ''', (order['id'],)).fetchall()
        orders_with_items.append({'order': order, 'items': items})
    conn.close()
    return render_template('orders.html', orders=orders_with_items)

@app.route('/review/<int:product_id>', methods=['POST'])
@login_required
def add_review(product_id):
    validate_csrf()
    try:
        rating = int(request.form.get('rating', 5))
    except (ValueError, TypeError):
        rating = 5
    comment = sanitize(request.form.get('comment', ''), 1000)
    if rating < 1 or rating > 5:
        flash('Оценка от 1 до 5', 'danger')
        return redirect(url_for('product_detail', product_id=product_id))

    conn = get_db()
    existing = conn.execute(
        'SELECT id FROM reviews WHERE product_id = ? AND user_id = ?',
        (product_id, current_user.id)
    ).fetchone()
    if existing:
        flash('Вы уже оставляли отзыв на этот товар', 'warning')
        conn.close()
        return redirect(url_for('product_detail', product_id=product_id))

    conn.execute(
        'INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)',
        (product_id, current_user.id, rating, comment)
    )
    avg = conn.execute('SELECT AVG(rating) FROM reviews WHERE product_id = ?', (product_id,)).fetchone()[0]
    conn.execute('UPDATE products SET rating = ? WHERE id = ?', (round(avg, 1), product_id))
    conn.commit()
    conn.close()
    log_audit('review_added', f'Product #{product_id}, rating={rating}')
    flash('Отзыв добавлен!', 'success')
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/profile')
@login_required
def profile():
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (current_user.id,)).fetchone()
    order_count = conn.execute('SELECT COUNT(*) FROM orders WHERE user_id = ?', (current_user.id,)).fetchone()[0]
    cart_count = conn.execute('SELECT COUNT(*) FROM cart WHERE user_id = ?', (current_user.id,)).fetchone()[0]
    conn.close()
    return render_template('profile.html', user=user, order_count=order_count, cart_count=cart_count)

# ==================== ADMIN ====================

@app.route('/admin')
@login_required
@admin_required
def admin():
    tab = sanitize(request.args.get('tab', 'orders'), 20)
    conn = get_db()

    products = conn.execute(
        'SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id ORDER BY p.id'
    ).fetchall()
    orders = conn.execute('''
        SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC LIMIT 50
    ''').fetchall()
    users = conn.execute(
        'SELECT id, username, email, is_admin, is_active, failed_logins, locked_until, created_at FROM users ORDER BY id'
    ).fetchall()

    # Audit log with optional filter
    audit_filter = sanitize(request.args.get('audit_filter', ''), 50)
    audit_q = '''SELECT a.*, u.username FROM audit_log a
                 LEFT JOIN users u ON a.user_id = u.id WHERE 1=1'''
    audit_params = []
    if audit_filter:
        audit_q += ' AND (a.action LIKE ? OR a.details LIKE ? OR a.ip_address LIKE ?)'
        audit_params.extend([f'%{audit_filter}%'] * 3)
    audit_q += ' ORDER BY a.created_at DESC LIMIT 100'
    audit_logs = conn.execute(audit_q, audit_params).fetchall()

    # Security stats
    security = {
        'failed_logins_24h': conn.execute(
            "SELECT COUNT(*) FROM audit_log WHERE action='login_fail' AND created_at > datetime('now', '-1 day')"
        ).fetchone()[0],
        'locked_users': conn.execute(
            "SELECT COUNT(*) FROM users WHERE locked_until IS NOT NULL AND locked_until > datetime('now')"
        ).fetchone()[0],
        'inactive_users': conn.execute('SELECT COUNT(*) FROM users WHERE is_active = 0').fetchone()[0],
        'csrf_fails': conn.execute(
            "SELECT COUNT(*) FROM audit_log WHERE action='csrf_fail' AND created_at > datetime('now', '-1 day')"
        ).fetchone()[0],
        'admin_denies': conn.execute(
            "SELECT COUNT(*) FROM audit_log WHERE action='admin_access_denied' AND created_at > datetime('now', '-7 day')"
        ).fetchone()[0],
    }

    stats = {
        'products': conn.execute('SELECT COUNT(*) FROM products').fetchone()[0],
        'users': conn.execute('SELECT COUNT(*) FROM users').fetchone()[0],
        'orders': conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0],
        'revenue': conn.execute('SELECT COALESCE(SUM(total), 0) FROM orders').fetchone()[0],
        'reviews': conn.execute('SELECT COUNT(*) FROM reviews').fetchone()[0],
        'low_stock': conn.execute('SELECT COUNT(*) FROM products WHERE stock < 10').fetchone()[0],
    }

    # Reviews for moderation
    reviews = conn.execute('''
        SELECT r.*, u.username, p.name as product_name FROM reviews r
        JOIN users u ON r.user_id = u.id JOIN products p ON r.product_id = p.id
        ORDER BY r.created_at DESC LIMIT 30
    ''').fetchall()

    categories = conn.execute('SELECT * FROM categories').fetchall()
    conn.close()

    return render_template('admin.html', products=products, orders=orders, users=users,
                           audit_logs=audit_logs, stats=stats, security=security,
                           reviews=reviews, categories=categories, tab=tab,
                           audit_filter=audit_filter)

@app.route('/admin/order/<int:order_id>/status', methods=['POST'])
@login_required
@admin_required
def update_order_status(order_id):
    validate_csrf()
    status = sanitize(request.form.get('status', ''), 20)
    valid = ['pending', 'processing', 'shipped', 'delivered', 'cancelled']
    if status in valid:
        conn = get_db()
        old = conn.execute('SELECT status FROM orders WHERE id = ?', (order_id,)).fetchone()
        conn.execute('UPDATE orders SET status = ? WHERE id = ?', (status, order_id))
        conn.commit()
        conn.close()
        log_audit('order_status_change',
                  f'Order #{order_id}: {old["status"] if old else "?"} → {status}')
        flash('Статус заказа обновлён', 'success')
    return redirect(url_for('admin', tab='orders'))

@app.route('/admin/user/<int:user_id>/toggle_active', methods=['POST'])
@login_required
@admin_required
def toggle_user_active(user_id):
    validate_csrf()
    if user_id == current_user.id:
        flash('Нельзя деактивировать самого себя', 'danger')
        return redirect(url_for('admin', tab='users'))
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    if user:
        new_state = 0 if user['is_active'] else 1
        conn.execute('UPDATE users SET is_active = ?, failed_logins = 0, locked_until = NULL WHERE id = ?',
                    (new_state, user_id))
        conn.commit()
        action = 'user_activated' if new_state else 'user_deactivated'
        log_audit(action, f'User: {user["username"]} (id={user_id})', severity='warning')
        flash(f'Пользователь {"активирован" if new_state else "деактивирован"}', 'success')
    conn.close()
    return redirect(url_for('admin', tab='users'))

@app.route('/admin/user/<int:user_id>/toggle_admin', methods=['POST'])
@login_required
@admin_required
def toggle_user_admin(user_id):
    validate_csrf()
    if user_id == current_user.id:
        flash('Нельзя снять права с самого себя', 'danger')
        return redirect(url_for('admin', tab='users'))
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    if user:
        new_state = 0 if user['is_admin'] else 1
        conn.execute('UPDATE users SET is_admin = ? WHERE id = ?', (new_state, user_id))
        conn.commit()
        log_audit('user_admin_toggle',
                  f'User: {user["username"]} admin={new_state}', severity='warning')
        flash(f'Права администратора {"выданы" if new_state else "сняты"}', 'success')
    conn.close()
    return redirect(url_for('admin', tab='users'))

@app.route('/admin/user/<int:user_id>/unlock', methods=['POST'])
@login_required
@admin_required
def unlock_user(user_id):
    validate_csrf()
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    if user:
        conn.execute('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?', (user_id,))
        conn.commit()
        log_audit('user_unlocked', f'User: {user["username"]}')
        flash('Пользователь разблокирован', 'success')
    conn.close()
    return redirect(url_for('admin', tab='users'))

@app.route('/admin/product/<int:product_id>/update', methods=['POST'])
@login_required
@admin_required
def update_product(product_id):
    validate_csrf()
    try:
        price = float(request.form.get('price', 0))
        stock = int(request.form.get('stock', 0))
    except (ValueError, TypeError):
        flash('Некорректные данные', 'danger')
        return redirect(url_for('admin', tab='products'))
    if price < 0 or stock < 0:
        flash('Цена и склад не могут быть отрицательными', 'danger')
        return redirect(url_for('admin', tab='products'))

    conn = get_db()
    old = conn.execute('SELECT name, price, stock FROM products WHERE id = ?', (product_id,)).fetchone()
    if old:
        conn.execute('UPDATE products SET price = ?, stock = ? WHERE id = ?', (price, stock, product_id))
        conn.commit()
        log_audit('product_update',
                  f'{old["name"]}: price {old["price"]}→{price}, stock {old["stock"]}→{stock}')
        flash('Товар обновлён', 'success')
    conn.close()
    return redirect(url_for('admin', tab='products'))

@app.route('/admin/review/<int:review_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_review(review_id):
    validate_csrf()
    conn = get_db()
    review = conn.execute('SELECT * FROM reviews WHERE id = ?', (review_id,)).fetchone()
    if review:
        product_id = review['product_id']
        conn.execute('DELETE FROM reviews WHERE id = ?', (review_id,))
        avg = conn.execute('SELECT AVG(rating) FROM reviews WHERE product_id = ?', (product_id,)).fetchone()[0]
        conn.execute('UPDATE products SET rating = ? WHERE id = ?',
                    (round(avg, 1) if avg else 4.5, product_id))
        conn.commit()
        log_audit('review_deleted', f'Review #{review_id}, product #{product_id}', severity='warning')
        flash('Отзыв удалён', 'success')
    conn.close()
    return redirect(url_for('admin', tab='reviews'))

@app.route('/admin/audit/clear', methods=['POST'])
@login_required
@admin_required
def clear_old_audit():
    validate_csrf()
    conn = get_db()
    conn.execute("DELETE FROM audit_log WHERE created_at < datetime('now', '-30 day')")
    deleted = conn.execute('SELECT changes()').fetchone()[0]
    conn.commit()
    conn.close()
    log_audit('audit_cleared', f'Deleted {deleted} old entries', severity='warning')
    flash(f'Удалено {deleted} старых записей аудита (>30 дней)', 'success')
    return redirect(url_for('admin', tab='audit'))

# ==================== ERROR HANDLERS ====================

@app.errorhandler(403)
def forbidden(e):
    flash('Доступ запрещён (CSRF или права)', 'danger')
    return redirect(url_for('index'))

@app.errorhandler(404)
def not_found(e):
    return render_template('base.html', **{'content': ''}), 404

@app.errorhandler(500)
def server_error(e):
    return 'Внутренняя ошибка сервера', 500

# ==================== MAIN ====================

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
