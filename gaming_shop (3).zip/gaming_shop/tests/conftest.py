import os
import sys
import tempfile
import pytest

# Ensure project root is on path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from config import Config
from database import init_db, get_db


class TestConfig(Config):
    TESTING = True
    SECRET_KEY = 'test-secret-key-not-for-production'
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app():
    """Create application with temporary database."""
    db_fd, db_path = tempfile.mkstemp(suffix='.db')
    TestConfig.DATABASE = db_path

    application = create_app(TestConfig)

    with application.app_context():
        # Override database path used by get_db
        import config as cfg
        cfg.Config.DATABASE = db_path
        init_db()

    yield application

    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def csrf_token(client):
    """Fetch a valid CSRF token from the login page."""
    import re
    r = client.get('/login')
    m = re.search(r'name="csrf_token" value="([^"]+)"', r.data.decode())
    assert m, 'CSRF token not found on login page'
    return m.group(1)


def login(client, username, password, csrf):
    return client.post('/login', data={
        'username': username,
        'password': password,
        'csrf_token': csrf,
    }, follow_redirects=True)


def login_as_admin(client, csrf):
    return login(client, 'admin', 'admin123', csrf)


def login_as_demo(client, csrf):
    return login(client, 'demo', 'demo123', csrf)
