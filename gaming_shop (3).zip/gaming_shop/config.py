import os
import secrets
from datetime import timedelta


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
    DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shop.db')

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = False  # True in production with HTTPS
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    MAX_CONTENT_LENGTH = 1 * 1024 * 1024  # 1 MB

    MAX_LOGIN_ATTEMPTS = 5
    LOCKOUT_MINUTES = 15
    MAX_REGISTER_ATTEMPTS = 3
