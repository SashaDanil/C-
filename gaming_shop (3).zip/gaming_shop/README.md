# GameGear — Интернет-магазин игровой периферии

Flask-приложение с модульной архитектурой, аудитом и тестами.

## Структура

```
gaming_shop/
├── app.py              # Точка входа, create_app()
├── config.py           # Конфигурация
├── extensions.py       # Flask-Login
├── database.py         # SQLite: get_db, init_db, seed
├── models.py           # User model
├── security.py         # CSRF, rate-limit, sanitize, audit, headers
├── routes/
│   ├── main.py         # Главная, каталог, товар
│   ├── auth.py         # Регистрация, вход, выход
│   ├── cart.py         # Корзина, заказ, отзывы, профиль
│   └── admin.py        # Админ-панель + аудит
├── templates/
├── static/
├── tests/              # pytest
│   ├── conftest.py
│   ├── test_auth.py
│   ├── test_catalog.py
│   ├── test_cart.py
│   ├── test_admin.py
│   └── test_security.py
└── shop.db
```

## Запуск

```bash
cd gaming_shop
python3 app.py
# → http://127.0.0.1:5000
```

## Тесты

```bash
pip install flask flask-login pytest
cd gaming_shop
python3 -m pytest tests/ -v
```

## Демо-аккаунты

| Роль         | Логин  | Пароль   |
|--------------|--------|----------|
| Пользователь | demo   | demo123  |
| Админ        | admin  | admin123 |

## Безопасность

- CSRF-токены на всех POST
- Rate-limit входа/регистрации
- Блокировка аккаунта после неудачных попыток
- Security headers (CSP, X-Frame-Options, …)
- Журнал аудита
- Санитизация ввода, параметризованный SQL
