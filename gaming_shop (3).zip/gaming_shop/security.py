import re
import time
import secrets
from collections import defaultdict
from functools import wraps

from flask import request, session, abort, flash, redirect, url_for
from flask_login import current_user

from config import Config
from database import get_db

_login_attempts = defaultdict(list)
_register_attempts = defaultdict(list)


def get_client_ip():
    return request.headers.get('X-Forwarded-For', request.remote_addr) or '0.0.0.0'


def sanitize(text, max_len=500):
    if not text:
        return ''
    text = str(text).strip()
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
    return text[:max_len]


def is_valid_email(email):
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))


def is_strong_password(password):
    if len(password) < 6:
        return False, 'Пароль должен быть не менее 6 символов'
    return True, ''


def check_rate_limit(store, ip, max_attempts, window_minutes):
    now = time.time()
    window = window_minutes * 60
    store[ip] = [t for t in store[ip] if now - t < window]
    return len(store[ip]) < max_attempts


def record_attempt(store, ip):
    store[ip].append(time.time())


def log_audit(action, details='', user_id=None, severity='info'):
    try:
        conn = get_db()
        uid = user_id
        if uid is None and hasattr(current_user, 'is_authenticated') and current_user.is_authenticated:
            uid = current_user.id
        conn.execute(
            '''INSERT INTO audit_log (user_id, action, details, ip_address, user_agent, severity)
               VALUES (?, ?, ?, ?, ?, ?)''',
            (
                uid, action, sanitize(details, 1000), get_client_ip(),
                sanitize(request.headers.get('User-Agent', ''), 300), severity,
            ),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def generate_csrf_token():
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']


def validate_csrf():
    token = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
    if not token or token != session.get('_csrf_token'):
        log_audit('csrf_fail', f'Path: {request.path}', severity='warning')
        abort(403)


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            log_audit('admin_access_denied', f'Path: {request.path}', severity='warning')
            flash('Доступ только для администратора', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated


def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "img-src 'self' data: https: http:; "
        "font-src 'self' https://cdn.jsdelivr.net; "
        "frame-ancestors 'self';"
    )
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private'
    return response
